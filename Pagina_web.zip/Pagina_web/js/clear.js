function clr_registo() {
    document.getElementById("email").value = "";
    document.getElementById("nombre").value = "";
    document.getElementById("apellido").value = "";
    document.getElementById("nickname").value = "";
    document.getElementById("password").value = "";
    alert("Formulario Borrado!");
    }

    function clr_ingreso() {
        document.getElementById("email").value = "";
        document.getElementById("password").value = "";
        alert("Formulario Borrado!");
        }

    function clr_Elusuario() {
        document.getElementById("email").value = "";
        document.getElementById("nickname").value = "";
        alert("Formulario Borrado!");
        }

    function clr_pr() {
        document.getElementById("id_producto").value = "";
        document.getElementById("nombre_p").value = "";
        document.getElementById("nombre_pi").value = "";
        alert("Formulario Borrado!");
        }

     function clr_cr() {
        document.getElementById("nombre_p").value = "";
        document.getElementById("d_producto").value = "";
        document.getElementById("u_m_p").value = "";
        document.getElementById("c_i_p").value = "";
        alert("Formulario Borrado!");
        }

    function clr_co_id() {
        document.getElementById("consulta_p").value = "";
        alert("Formulario Borrado!");
        }

    function clr_aj_ip() {
        document.getElementById("id_producto").value = "";
        document.getElementById("nombre_p").value = "";
        document.getElementById("nombre_pi").value = "";
        document.getElementById("n_c_p").value = "";
        alert("Formulario Borrado!");
        }
    